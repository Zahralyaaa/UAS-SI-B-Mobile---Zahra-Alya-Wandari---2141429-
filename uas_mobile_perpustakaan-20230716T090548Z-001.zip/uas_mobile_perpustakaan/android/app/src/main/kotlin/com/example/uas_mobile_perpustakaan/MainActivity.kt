package com.example.uas_mobile_perpustakaan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
