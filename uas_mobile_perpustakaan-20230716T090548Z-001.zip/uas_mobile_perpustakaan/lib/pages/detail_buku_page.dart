import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';

class DetailBukuPage extends StatefulWidget {
  final Map<String, dynamic> bukuData;

  DetailBukuPage({required this.bukuData});

  @override
  _DetailBukuPageState createState() => _DetailBukuPageState();
}

class _DetailBukuPageState extends State<DetailBukuPage> {
  late Map<String, dynamic> bukuData;

  @override
  void initState() {
    super.initState();
    bukuData = widget.bukuData;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        top: false,
        child: SingleChildScrollView(
          child: Center(
            child: Column(
              children: [
                Container(
                  width: 500,
                  height: 300,
                  decoration: BoxDecoration(
                    color: Colors.blue,
                  ),
                  child: Stack(
                    overflow: Overflow.visible,
                    alignment: Alignment.center,
                    children: [
                      Positioned(
                        top: 30,
                        right: 125,
                        child: Container(
                          child: Row(
                            children: [
                              IconButton(
                                icon: Icon(
                                  Icons.arrow_back,
                                  size: 24,
                                  color: Colors.black,
                                ),
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                              ),
                              SizedBox(width: 100),
                              Text(
                                "DETAIL BUKU",
                                style: TextStyle(
                                  fontSize: 22,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: -75,
                        child: Container(
                          color: Colors.grey,
                          child: Stack(
                            children: [
                              Container(
                                height: 260,
                                width: 185,
                                child: Image.network(
                                  bukuData['image'],
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 100),
                Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: 225,
                        child: Text(
                          bukuData['judul'],
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                          ),
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                        ),
                      ),
                      Container(
                        width: 225,
                        child: Text(
                          "Oleh ${bukuData['penulis']}",
                          style: TextStyle(
                            fontSize: 20,
                          ),
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 75,
                            child: Text(
                              "Rating",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 18,
                              ),
                              textAlign: TextAlign.center,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                          Container(
                            width: 75,
                            child: Text(
                              bukuData['rating'],
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                              ),
                              textAlign: TextAlign.center,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(width: 50),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 100,
                            child: Text(
                              "Bahasa",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 18,
                              ),
                              textAlign: TextAlign.center,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                          Container(
                            width: 100,
                            child: Text(
                              bukuData['bahasa'],
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                              ),
                              textAlign: TextAlign.center,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(width: 50),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 75,
                            child: Text(
                              "Tahun",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 18,
                              ),
                              textAlign: TextAlign.center,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                          Container(
                            width: 75,
                            child: Text(
                              bukuData['tahun'],
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                              ),
                              textAlign: TextAlign.center,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 30),
                Container(
                  width: 365,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "SINOPSIS",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(height: 10),
                      Container(
                        width: 375,
                        child: Text(
                          bukuData['sinopsis'],
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.grey,
                          ),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 15,
                        ),
                      ),
                      SizedBox(height: 30),
                      Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            GestureDetector(
                              onTap: () {
                                _updateKeteranganBaca();
                              },
                              child: Container(
                                width: 125,
                                height: 45,
                                clipBehavior: Clip.antiAlias,
                                decoration: ShapeDecoration(
                                  color: Colors.blue,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            'BACA',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 16,
                                              fontFamily: 'Roboto',
                                              fontWeight: FontWeight.w500,
                                              letterSpacing: 0.10,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(width: 10),
                            GestureDetector(
                              onTap: () {
                                _updateKeteranganSimpan();
                              },
                              child: Container(
                                width: 45,
                                height: 45,
                                clipBehavior: Clip.antiAlias,
                                decoration: ShapeDecoration(
                                  color: Colors.grey,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Icon(
                                            bukuData['keterangan_simpan'] == "1"
                                                ? Icons.check
                                                : Icons.add,
                                            size: 24,
                                            color: Colors.black,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 40),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _updateKeteranganBaca() async {
    final id = bukuData['id'];
    final url = Uri.parse(
        'https://aplikasi-mobile-perputakaan-default-rtdb.asia-southeast1.firebasedatabase.app/book/$id.json');

    final currentDate = DateTime.now();
    final formattedDate = DateFormat('dd/MM/yyyy').format(currentDate);

    final response = await http.put(
      url,
      body: jsonEncode({
        "judul": bukuData['judul'],
        "penulis": bukuData['penulis'],
        "rating": bukuData['rating'],
        "bahasa": bukuData['bahasa'],
        "tahun": bukuData['tahun'],
        "sinopsis": bukuData['sinopsis'],
        "image": bukuData['image'],
        "link_download_pdf": bukuData['link_download_pdf'],
        "keterangan_baca": "1",
        "keterangan_simpan": bukuData['keterangan_simpan'],
        "total_view": bukuData['total_view'],
        "terakhir_baca": formattedDate, // Update terakhir_baca dengan tanggal hari ini
      }),
    );

    if (response.statusCode == 200) {
      // Data berhasil diperbarui
      print('Data berhasil diperbarui');
    } else {
      // Gagal mengirim permintaan
      print('Gagal mengirim permintaan');
    }
  }

  void _updateKeteranganSimpan() async {
    final id = bukuData['id'];

    if (bukuData['keterangan_simpan'] == "0") {
      final url = Uri.parse(
          'https://aplikasi-mobile-perputakaan-default-rtdb.asia-southeast1.firebasedatabase.app/book/$id.json');
      final response = await http.put(
        url,
        body: jsonEncode({
          "judul": bukuData['judul'],
          "penulis": bukuData['penulis'],
          "rating": bukuData['rating'],
          "bahasa": bukuData['bahasa'],
          "tahun": bukuData['tahun'],
          "sinopsis": bukuData['sinopsis'],
          "image": bukuData['image'],
          "link_download_pdf": bukuData['link_download_pdf'],
          "keterangan_baca": bukuData['keterangan_baca'],
          "keterangan_simpan": "1",
          "total_view": bukuData['total_view'],
          "terakhir_baca": bukuData['terakhir_baca'],
        }),
      );

      if (response.statusCode == 200) {
        setState(() {
          bukuData['keterangan_simpan'] = "1";
        });
        print('Data berhasil diperbarui');
      } else {
        print('Gagal mengirim permintaan');
      }
    } else if (bukuData['keterangan_simpan'] == "1") {
      final url = Uri.parse(
          'https://aplikasi-mobile-perputakaan-default-rtdb.asia-southeast1.firebasedatabase.app/book/$id.json');
      final response = await http.put(
        url,
        body: jsonEncode({
          "judul": bukuData['judul'],
          "penulis": bukuData['penulis'],
          "rating": bukuData['rating'],
          "bahasa": bukuData['bahasa'],
          "tahun": bukuData['tahun'],
          "sinopsis": bukuData['sinopsis'],
          "image": bukuData['image'],
          "link_download_pdf": bukuData['link_download_pdf'],
          "keterangan_baca": bukuData['keterangan_baca'],
          "keterangan_simpan": "0",
          "total_view": bukuData['total_view'],
          "terakhir_baca": bukuData['terakhir_baca'],
        }),
      );

      if (response.statusCode == 200) {
        setState(() {
          bukuData['keterangan_simpan'] = "0";
        });
        print('Data berhasil diperbarui');
      } else {
        print('Gagal mengirim permintaan');
      }
    }
  }
}