import 'package:flutter/material.dart';
import 'beranda_page.dart';
import 'kategori_page.dart';
import 'buku_saya_page.dart';
import 'profile_page.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    BerandaPage(),
    KategoriPage(),
    BukuSayaPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _pages,
      ),
      bottomNavigationBar: Container(
        height: 60,
        color: Color(0xFF389FFF),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            InkWell(
              onTap: () {
                setState(() {
                  _selectedIndex = 0;
                });
              },
              child: Container(
                padding: EdgeInsets.all(8),
                child: Icon(Icons.home, size: 38, color: Colors.black),
              ),
            ),
            InkWell(
              onTap: () {
                setState(() {
                  _selectedIndex = 1;
                });
              },
              child: Container(
                padding: EdgeInsets.all(8),
                child: Icon(Icons.category, size: 35, color: Colors.black),
              ),
            ),
            InkWell(
              onTap: () {
                setState(() {
                  _selectedIndex = 2;
                });
              },
              child: Container(
                padding: EdgeInsets.all(8),
                child: Icon(Icons.book, size: 35, color: Colors.black),
              ),
            ),
            InkWell(
              onTap: () {
                setState(() {
                  _selectedIndex = 3;
                });
              },
              child: Container(
                padding: EdgeInsets.all(8),
                child: Icon(Icons.person, size: 38, color: Colors.black),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


