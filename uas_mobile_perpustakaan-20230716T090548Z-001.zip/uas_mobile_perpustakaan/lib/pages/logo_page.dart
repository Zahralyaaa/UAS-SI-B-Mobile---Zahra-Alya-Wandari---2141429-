import 'package:flutter/material.dart';
import 'login_page.dart';

class IntroPage extends StatefulWidget {

  @override
  _IntroPageState createState() => _IntroPageState();
}

class _IntroPageState extends State<IntroPage> {
  @override
  void initState() {
    super.initState();
    navigateToLoginScreenDelayed();
  }

  void navigateToLoginScreenDelayed() {
    Future.delayed(Duration(seconds: 2), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginPage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;

    Widget buildIntroLogoScreen() {
      return Scaffold(
        resizeToAvoidBottomInset: false,
        body: SafeArea(
          top: false,
          child: Center(
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(color: const Color(0xFF0075FF)),
                  width: screenSize.width,
                  height: screenSize.height,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        child: Image.asset(
                          "assets/logo/rectangle5.png",
                          width: 261,
                          height: 249,
                        ),
                      ),
                      SizedBox(height: 30),
                      Text(
                        "Selamat Datang di\nPerpustakaan Digital",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return buildIntroLogoScreen();
  }
}
