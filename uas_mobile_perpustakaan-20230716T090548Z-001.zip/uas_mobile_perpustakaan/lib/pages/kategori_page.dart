import 'package:flutter/material.dart';
import 'kategori_buku.dart';
import 'kategori_jurnal.dart';
import 'kategori_kerja_praktik.dart';
import 'kategori_skripsi.dart';
import 'kategori_tesis.dart';
import 'kategori_tugas_akhir.dart';

class KategoriPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SingleChildScrollView(
        padding: EdgeInsets.only(top: 16.0),
        child: Center(
          child: Column(
            children: [
              SizedBox(height: 20),
              Container(
                child: Row(
                  children: [
                    SizedBox(
                      height: 30,
                      width: 30,
                    ),
                    Text(
                      "CATEGORY",
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.w700,
                        color: Colors.blue,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Text(
                "DOKUMEN",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(height: 20),
              GestureDetector(
                onTap: () {
                  // Navigasi ke halaman Tugas Akhir
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => KategoriTugasAkhir()),
                  );
                },
                child: Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Image.asset(
                              "assets/kategori/think-different1.png",
                              width: 53,
                              height: 48,
                            ),
                            SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Tugas Akhir",
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 30),
                      GestureDetector(
                        onTap: () {
                          // Navigasi ke halaman Kerja Praktik
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => KategoriKerjaPraktik()),
                          );
                        },
                        child: Container(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Image.asset(
                                "assets/kategori/book1.png",
                                width: 53,
                                height: 48,
                              ),
                              SizedBox(width: 10),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Kerja Praktik",
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),
              Text(
                "KATEGORI BUKU",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(height: 20),
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () {
                        // Navigasi ke halaman Buku
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => KategoriBuku()),
                        );
                      },
                      child: Column(
                        children: [
                          Container(
                            child: Column(
                              children: [
                                Image.asset(
                                  "assets/kategori/rectangle26.png",
                                  width: 98,
                                  height: 106,
                                ),
                                SizedBox(height: 10),
                                Text(
                                  "BUKU",
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 30),
                          GestureDetector(
                            onTap: () {
                              // Navigasi ke halaman Skripsi
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => KategoriSkripsi()),
                              );
                            },
                            child: Container(
                              child: Column(
                                children: [
                                  Image.asset(
                                    "assets/kategori/rectangle28.png",
                                    width: 98,
                                    height: 106,
                                  ),
                                  SizedBox(height: 10),
                                  Text(
                                    "SKRIPSI",
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 45),
                    GestureDetector(
                      onTap: () {
                        // Navigasi ke halaman Jurnal
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => KategoriJurnal()),
                        );
                      },
                      child: Column(
                        children: [
                          Container(
                            child: Column(
                              children: [
                                Image.asset(
                                  "assets/kategori/rectangle27.png",
                                  width: 98,
                                  height: 106,
                                ),
                                SizedBox(height: 10),
                                Text(
                                  "JURNAL",
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 30),
                          GestureDetector(
                            onTap: () {
                              // Navigasi ke halaman Tesis
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => KategoriTesis()),
                              );
                            },
                            child: Container(
                              child: Column(
                                children: [
                                  Image.asset(
                                    "assets/kategori/rectangle29.png",
                                    width: 98,
                                    height: 106,
                                  ),
                                  SizedBox(height: 10),
                                  Text(
                                    "TESIS",
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
