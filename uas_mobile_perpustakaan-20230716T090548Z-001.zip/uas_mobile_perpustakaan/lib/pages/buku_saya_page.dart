import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

import 'detail_buku_page.dart';

class BukuSayaPage extends StatefulWidget {
  @override
  _BukuSayaPageState createState() => _BukuSayaPageState();
}

class _BukuSayaPageState extends State<BukuSayaPage>
    with AutomaticKeepAliveClientMixin<BukuSayaPage> {
  final PageController _pageController = PageController(initialPage: 0);
  List<dynamic> bukuSimpanData = [];
  List<dynamic> riwayatBacaData = [];
  bool isSwitched = true;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      final url = Uri.parse(
          'https://aplikasi-mobile-perputakaan-default-rtdb.asia-southeast1.firebasedatabase.app/book.json');
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body) as Map<String, dynamic>;

        final bukuSimpanList = [];
        final riwayatBacaList = [];

        data.entries.forEach((entry) {
          final buku = entry.value;
          final id = entry.key;

          if (buku['keterangan_simpan'] == '1') {
            buku['id'] = id;
            bukuSimpanList.add(buku);
          }

          if (buku['keterangan_baca'] == '1') {
            buku['id'] = id;
            riwayatBacaList.add(buku);
          }
        });

        setState(() {
          bukuSimpanData = bukuSimpanList;
          riwayatBacaData = riwayatBacaList;
        });
      } else {
        print('Request failed with status: ${response.statusCode}.');
      }
    } catch (error) {
      print('Error: $error');
    }
  }

  void refreshData() {
    fetchData();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return Scaffold(
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 25),
              Row(
                children: [
                  SizedBox(width: 50),
                  Expanded(
                    child: Text(
                      'BUKU SAYA',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 22,
                        color: Colors.blue,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.refresh),
                    onPressed: refreshData,
                  ),
                ],
              ),
              SizedBox(height: 25),
              Container(
                height: 40,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: () {
                        _pageController.animateToPage(0,
                            duration: Duration(milliseconds: 300),
                            curve: Curves.ease);
                        setState(() {
                          isSwitched = true;
                        });
                      },
                      child: Container(
                        width: 180,
                        child: Column(
                          children: [
                            Text(
                              'BUKU YANG DISIMPAN',
                              style: TextStyle(
                                fontSize: 14,
                                color: !isSwitched ? Colors.grey : Colors.blue,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            SizedBox(height: 8),
                            if (isSwitched)
                              Container(
                                width: 180,
                                height: 1,
                                color: isSwitched ? Colors.blue : Colors.grey,
                              ),
                          ],
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        _pageController.animateToPage(1,
                            duration: Duration(milliseconds: 300),
                            curve: Curves.ease);
                        setState(() {
                          isSwitched = false;
                        });
                      },
                      child: Container(
                        width: 180,
                        child: Column(
                          children: [
                            Text(
                              'RIWAYAT BACA',
                              style: TextStyle(
                                fontSize: 14,
                                color: !isSwitched ? Colors.blue : Colors.grey,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            SizedBox(height: 8),
                            if (!isSwitched)
                              Container(
                                width: 180,
                                height: 1,
                                color: !isSwitched ? Colors.blue : Colors.grey,
                              ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                height: MediaQuery.of(context).size.height - 200,
                child: PageView.builder(
                  controller: _pageController,
                  scrollDirection: Axis.horizontal,
                  itemCount: 2,
                  itemBuilder: (context, index) {
                    if (index == 0) {
                      return bukuSimpanCard();
                    } else if (index == 1) {
                      return riwayatBacaCard();
                    }
                    return Container();
                  },
                  onPageChanged: (int index) {
                    setState(() {
                      isSwitched = index == 0;
                    });
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget bukuSimpanCard() {
    return ListView.builder(
      shrinkWrap: true,
      itemCount: bukuSimpanData.length,
      itemBuilder: (context, index) {
        final buku = bukuSimpanData[index];
        final terakhirBaca = buku['terakhir_baca'];

        final terakhirBacaDate = DateFormat('dd/MM/yyyy').parse(terakhirBaca);

        final difference = DateTime.now().difference(terakhirBacaDate).inDays;

        String terakhirBacaText;
        if (difference == 0) {
          terakhirBacaText = 'Hari Ini';
        } else if (difference == 1) {
          terakhirBacaText = 'Kemarin';
        } else if (difference < 7) {
          terakhirBacaText = 'Minggu Lalu';
        } else {
          terakhirBacaText = 'Bulan Lalu';
        }

        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => DetailBukuPage(bukuData: buku),
              ),
            );
          },
          child: Container(
            child: Card(
              child: Row(
                children: [
                  Container(
                    width: 75,
                    height: 150,
                    child: Image.network(
                      buku['image'],
                      fit: BoxFit.cover,
                    ),
                  ),
                  SizedBox(width: 15),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 250,
                        child: Text(
                          buku['judul'],
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                        ),
                      ),
                      SizedBox(height: 3),
                      Container(
                        width: 250,
                        child: Text(
                          buku['sinopsis'],
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                          ),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                        ),
                      ),
                      SizedBox(height: 12),
                      Container(
                        width: 250,
                        child: Text(
                          "Oleh ${buku['penulis']}",
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                          ),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                        ),
                      ),
                      SizedBox(height: 40),
                      Text(
                        terakhirBacaText,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget riwayatBacaCard() {
    return ListView.builder(
      shrinkWrap: true,
      itemCount: riwayatBacaData.length,
      itemBuilder: (context, index) {
        final buku = riwayatBacaData[index];
        final terakhirBaca = buku['terakhir_baca'];

        final terakhirBacaDate = DateFormat('dd/MM/yyyy').parse(terakhirBaca);

        final difference = DateTime.now().difference(terakhirBacaDate).inDays;

        String terakhirBacaText;
        if (difference == 0) {
          terakhirBacaText = 'Hari Ini';
        } else if (difference == 1) {
          terakhirBacaText = 'Kemarin';
        } else if (difference < 7) {
          terakhirBacaText = 'Minggu Lalu';
        } else {
          terakhirBacaText = 'Bulan Lalu';
        }

        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => DetailBukuPage(bukuData: buku),
              ),
            );
          },
          child: Container(
            child: Card(
              child: Row(
                children: [
                  Container(
                    width: 75,
                    height: 150,
                    child: Image.network(
                      buku['image'],
                      fit: BoxFit.cover,
                    ),
                  ),
                  SizedBox(width: 15),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 250,
                        child: Text(
                          buku['judul'],
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                        ),
                      ),
                      SizedBox(height: 3),
                      Container(
                        width: 250,
                        child: Text(
                          buku['sinopsis'],
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                          ),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                        ),
                      ),
                      SizedBox(height: 12),
                      Container(
                        width: 250,
                        child: Text(
                          "Oleh ${buku['penulis']}",
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                          ),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                        ),
                      ),
                      SizedBox(height: 40),
                      Text(
                        terakhirBacaText,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
