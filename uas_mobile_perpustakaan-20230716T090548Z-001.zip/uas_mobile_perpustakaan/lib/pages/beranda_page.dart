import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'detail_buku_page.dart';

class BerandaPage extends StatefulWidget {
  @override
  _BerandaPageState createState() => _BerandaPageState();
}

class _BerandaPageState extends State<BerandaPage> {
  List<dynamic> rekomendasiList = [];
  List<dynamic> riwayatBacaList = [];

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      final url = Uri.parse(
          'https://aplikasi-mobile-perputakaan-default-rtdb.asia-southeast1.firebasedatabase.app/book.json');
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body) as Map<String, dynamic>;

        final rekomendasiList = [];
        final riwayatBacaList = [];

        data.entries.forEach((entry) {
          final buku = entry.value;
          final id = entry.key;

          if (buku['total_view'] != null && int.parse(buku['total_view']) > 0) {
            buku['id'] = id;
            rekomendasiList.add(buku);
          }

          if (buku['keterangan_baca'] == '1') {
            buku['id'] = id;
            riwayatBacaList.add(buku);
          }
        });

        rekomendasiList.sort((a, b) {
          final int totalViewA = int.parse(a['total_view']);
          final int totalViewB = int.parse(b['total_view']);
          return totalViewB.compareTo(totalViewA);
        });

        setState(() {
          this.rekomendasiList = rekomendasiList;
          this.riwayatBacaList = riwayatBacaList;
        });
      } else {
        print('Request failed with status: ${response.statusCode}.');
      }
    } catch (error) {
      print('Error: $error');
    }
  }

  Future<void> _refreshData() async {
    await fetchData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        top: false,
        child: SingleChildScrollView(
          child: Center(
            child: Column(
              children: [
                Container(
                  width: 500,
                  height: 300,
                  decoration: BoxDecoration(
                    color: Colors.blue,
                  ),
                  child: Stack(
                    overflow: Overflow.visible,
                    alignment: Alignment.center,
                    children: [
                      Positioned(
                        top: 45,
                        right: 205,
                        child: Container(
                          child: Row(
                            children: [
                              SizedBox(
                                height: 30,
                                width: 30,
                              ),
                              Text(
                                "AMIK LIBRARY",
                                style: TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        top: 45,
                        right: 10,
                        child: IconButton(
                          icon: Icon(Icons.refresh),
                          color: Colors.white,
                          onPressed: _refreshData,
                        ),
                      ),
                      Positioned(
                        bottom: -40,
                        child: Container(
                          color: Colors.grey,
                          child: Stack(
                            children: [
                              Image.asset(
                                'assets/login/rectangle3.png',
                                fit: BoxFit.cover,
                              ),
                              Positioned(
                                top: 20,
                                left: 20,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(height: 15),
                                    Text(
                                      'SELAMAT DATANG',
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                    SizedBox(height: 40),
                                    Text(
                                      'PERPUSTAKAAN ONLINE ',
                                      style: TextStyle(
                                        fontSize: 24,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                    SizedBox(height: 5),
                                    Text(
                                      'STMIK “AMIKBANDUNG”',
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 70),
                Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "REKOMENDASI",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(height: 8),
                      Container(
                        width: 350,
                        height: 1,
                        color: Colors.black,
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  height: 150,
                  child: Row(
                    children: [
                      SizedBox(width: 17),
                      Container(
                        width: 355,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: rekomendasiList.length,
                          itemBuilder: (context, index) {
                            final buku = rekomendasiList[index];

                            return GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        DetailBukuPage(bukuData: buku),
                                  ),
                                );
                              },
                              child: Container(
                                margin: EdgeInsets.only(right: 5),
                                child: Card(
                                  child: Column(
                                    children: [
                                      Container(
                                        width: 65,
                                        height: 100,
                                        child: Image.network(
                                          buku['image'],
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      SizedBox(width: 15),
                                      Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          SizedBox(height: 5),
                                          Container(
                                            width: 65,
                                            child: Text(
                                              buku['judul'],
                                              style: TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.w400,
                                              ),
                                              overflow: TextOverflow.ellipsis,
                                              maxLines: 1,
                                            ),
                                          ),
                                          SizedBox(height: 2),
                                          Container(
                                            width: 65,
                                            child: Text(
                                              "Oleh ${buku['penulis']}",
                                              style: TextStyle(
                                                fontSize: 10,
                                                fontWeight: FontWeight.w400,
                                              ),
                                              overflow: TextOverflow.ellipsis,
                                              maxLines: 1,
                                            ),
                                          ),
                                          SizedBox(height: 5),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "RIWAYAT BACA",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(height: 8),
                      Container(
                        width: 350,
                        height: 1,
                        color: Colors.black,
                      ),
                    ],
                  ),
                ),
                Container(
                  width: 375,
                  child: ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: riwayatBacaList.length,
                    itemBuilder: (context, index) {
                      final buku = riwayatBacaList[index];

                      return GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  DetailBukuPage(bukuData: buku),
                            ),
                          );
                        },
                        child: Container(
                          margin: EdgeInsets.only(bottom: 10),
                          child: Card(
                            child: Row(
                              children: [
                                Container(
                                  width: 75,
                                  height: 150,
                                  child: Image.network(
                                    buku['image'],
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 15),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: 250,
                                      child: Text(
                                        buku['judul'],
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w400,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                      ),
                                    ),
                                    Container(
                                      width: 250,
                                      child: Text(
                                        buku['judul'],
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w700,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                      ),
                                    ),
                                    SizedBox(height: 3),
                                    Container(
                                      width: 250,
                                      child: Text(
                                        buku['sinopsis'],
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w400,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                      ),
                                    ),
                                    SizedBox(height: 12),
                                    Container(
                                      width: 250,
                                      child: Text(
                                        "Oleh ${buku['penulis']}",
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w400,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                      ),
                                    ),
                                    SizedBox(height: 40),
                                    Container(
                                      width: 250,
                                      child: Text(
                                        "Hari Ini",
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.grey,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: BerandaPage(),
  ));
}
